package com.techpulse.news;

public class Article {
    public String title = "", description = "", link = "", source = "", category = "", imageUrl = "";
    public long published = 0;
}