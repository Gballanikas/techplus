package com.techpulse.news;

import android.text.Html;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Locale;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.helpers.DefaultHandler;

public class RssReader {
    public static ArrayList<Article> read(String feedUrl, String source, String category) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(feedUrl).openConnection();
        c.setConnectTimeout(10000); c.setReadTimeout(15000);
        c.setRequestProperty("User-Agent", "TechPulse/1.1 Android RSS Reader");
        try (InputStream in = c.getInputStream()) {
            FeedHandler h = new FeedHandler(source, category);
            SAXParserFactory.newInstance().newSAXParser().parse(new InputSource(in), h);
            return h.items;
        } finally { c.disconnect(); }
    }

    static String clean(String s) {
        if (s == null) return "";
        return Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY).toString().replaceAll("\\s+", " ").trim();
    }

    static class FeedHandler extends DefaultHandler {
        ArrayList<Article> items = new ArrayList<>();
        Article current; String currentTag = ""; String source, category; StringBuilder buf = new StringBuilder();
        FeedHandler(String source, String category) { this.source=source; this.category=category; }
        public void startElement(String uri, String local, String qName, Attributes a) {
            String tag = (local == null || local.isEmpty()) ? qName : local;
            currentTag = tag.toLowerCase(Locale.US);
            if ("item".equalsIgnoreCase(qName) || "entry".equalsIgnoreCase(qName)) {
                current = new Article(); current.source=source; current.category=category;
            }
            if (current != null) {
                String url = a.getValue("url");
                if (url == null) url = a.getValue("href");
                String q = qName.toLowerCase(Locale.US);
                if (url != null && (q.contains("media") || q.contains("thumbnail") || q.equals("enclosure"))) current.imageUrl=url;
                if ("link".equalsIgnoreCase(qName) && url != null && current.link.isEmpty()) current.link=url;
            }
            buf.setLength(0);
        }
        public void characters(char[] ch, int start, int length) { buf.append(ch,start,length); }
        public void endElement(String uri, String local, String qName) {
            String tag=((local == null || local.isEmpty()) ? qName : local).toLowerCase(Locale.US);
            if (current != null) {
                String value=clean(buf.toString());
                if (tag.equals("title")) current.title=value;
                else if (tag.equals("description") || tag.equals("summary")) current.description=value;
                else if (tag.equals("link") && current.link.isEmpty()) current.link=value;
                else if (tag.equals("pubdate") || tag.equals("published") || tag.equals("updated")) current.published=parseDate(value);
                if (("item".equalsIgnoreCase(qName) || "entry".equalsIgnoreCase(qName)) && !current.title.isEmpty()) {
                    if (current.link.isEmpty()) current.link=current.title;
                    if (current.published == 0) current.published=System.currentTimeMillis();
                    items.add(current); current=null;
                }
            }
            buf.setLength(0);
        }
        long parseDate(String s) {
            try { return new java.text.SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss Z", Locale.US).parse(s).getTime(); } catch(Exception ignored) {}
            try { return new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssX", Locale.US).parse(s).getTime(); } catch(Exception ignored) {}
            return 0;
        }
    }
}
