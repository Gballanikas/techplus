# TechPulse Android

TechPulse is a lightweight Android technology/science/space news aggregator.

## Current v1 features
- Dark, card-based "clipboard" style feed
- Technology, Science and Space categories
- Pull/refresh button
- Multiple reputable RSS sources
- Duplicate headline suppression
- Opens the original publisher article
- No account or API key
- Works with Android 8.0+ (API 26+)

## Sources
The initial source list uses public RSS feeds from:
- Ars Technica
- ScienceDaily Technology
- ScienceDaily Science
- NASA
- NASA Jet Propulsion Laboratory

NASA explicitly publishes RSS feeds for its news and technology content, and JPL publishes a news RSS feed. Ars Technica also publishes RSS feeds for its content. ScienceDaily publishes dedicated science and technology RSS feeds.

## Build
Open the project in Android Studio with JDK 17 and let Android Studio install/resolve the Android Gradle Plugin dependencies.

Then:
Build > Build Bundle(s) / APK(s) > Build APK(s)

The generated debug APK will normally be:
app/build/outputs/apk/debug/app-debug.apk

## Important
This environment did not contain an Android SDK/Gradle installation, so an actual APK binary could not be compiled here. The project has been checked for the expected Android project structure and source-level consistency, but it has NOT been truthfully represented as device-tested.

## v4
- Custom TechPulse launcher icon based on the selected Option 2 design.
- Android adaptive launcher icon resources included.
