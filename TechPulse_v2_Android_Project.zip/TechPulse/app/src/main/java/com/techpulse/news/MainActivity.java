package com.techpulse.news;

import android.app.Activity;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public class MainActivity extends Activity {
    LinearLayout root, feed; TextView status; final ArrayList<Article> articles=new ArrayList<>();
    final ExecutorService executor=Executors.newFixedThreadPool(5); final Handler main=new Handler(Looper.getMainLooper());
    final String[] feeds={
        "https://feeds.arstechnica.com/arstechnica/index|Ars Technica|Technology",
        "https://www.sciencedaily.com/rss/top/technology.xml|ScienceDaily|Technology",
        "https://www.sciencedaily.com/rss/top/science.xml|ScienceDaily|Science",
        "https://www.nasa.gov/feed/|NASA|Space",
        "https://www.jpl.nasa.gov/feeds/news/|NASA JPL|Space"};
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    @Override public void onCreate(Bundle b){super.onCreate(b);buildUi();load();}
    TextView text(String s,float size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    int accent(String c){if("Technology".equals(c))return Color.rgb(65,145,255);if("Science".equals(c))return Color.rgb(60,190,145);if("Space".equals(c))return Color.rgb(165,105,245);return Color.rgb(105,140,255);}
    void buildUi(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(11,15,25));setContentView(root);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.setPadding(dp(20),dp(18),dp(14),dp(10));
        TextView logo=text("TechPulse",28,Color.WHITE);logo.setTypeface(null,1);top.addView(logo,new LinearLayout.LayoutParams(0,dp(50),1));
        Button refresh=new Button(this);refresh.setText("↻");refresh.setTextSize(22);refresh.setOnClickListener(v->load());top.addView(refresh,new LinearLayout.LayoutParams(dp(62),dp(50)));root.addView(top);
        status=text("Technology • Science • Space",14,Color.rgb(155,165,185));status.setPadding(dp(20),0,dp(20),dp(12));root.addView(status);
        HorizontalScrollView hsv=new HorizontalScrollView(this);LinearLayout chips=new LinearLayout(this);chips.setPadding(dp(14),0,dp(14),dp(14));
        String[] cats={"ALL","TECHNOLOGY","SCIENCE","SPACE"}; for(String c:cats){Button chip=new Button(this);chip.setText(c);chip.setTextSize(12);chip.setMinHeight(dp(48));chip.setAllCaps(false);chip.setTextColor(Color.WHITE);chip.setBackground(bg("ALL".equals(c)?Color.rgb(42,51,70):Color.rgb(28,35,52),accent(c.equals("ALL")?"":titleCase(c)),12));chip.setOnClickListener(v->filter(c));chips.addView(chip,new LinearLayout.LayoutParams(dp(118),dp(52)));}
        hsv.addView(chips);root.addView(hsv);
        ScrollView sv=new ScrollView(this);feed=new LinearLayout(this);feed.setOrientation(LinearLayout.VERTICAL);feed.setPadding(dp(12),0,dp(12),dp(30));sv.addView(feed);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
    }
    String titleCase(String s){if(s==null||s.isEmpty())return "";return s.substring(0,1)+s.substring(1).toLowerCase(Locale.US);}
    GradientDrawable bg(int color,int stroke,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));g.setStroke(dp(1),stroke);return g;}
    void load(){status.setText("Updating feeds…");feed.removeAllViews();articles.clear();for(String f:feeds){String[] p=f.split("\\|");executor.submit(()->{try{ArrayList<Article>a=RssReader.read(p[0],p[1],p[2]);for(Article x:a)if(x.imageUrl.isEmpty())x.imageUrl=findOgImage(x.link);main.post(()->{articles.addAll(a);render(articles);});}catch(Exception e){main.post(()->status.setText("Some feeds unavailable • showing available sources"));}});}}
    String findOgImage(String link){if(link==null||!link.startsWith("http"))return "";try{HttpURLConnection c=(HttpURLConnection)new URL(link).openConnection();c.setConnectTimeout(5000);c.setReadTimeout(7000);c.setRequestProperty("User-Agent","Mozilla/5.0 TechPulse");try(BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream()))){StringBuilder s=new StringBuilder();String line;int n=0;while((line=r.readLine())!=null&&n++<500)s.append(line).append('\n');Matcher m=Pattern.compile("<meta[^>]+property=[\\\"']og:image[\\\"'][^>]+content=[\\\"']([^\\\"']+)",Pattern.CASE_INSENSITIVE).matcher(s);if(m.find())return m.group(1);m=Pattern.compile("<meta[^>]+content=[\\\"']([^\\\"']+)[\\\"'][^>]+property=[\\\"']og:image[\\\"']",Pattern.CASE_INSENSITIVE).matcher(s);if(m.find())return m.group(1);}finally{c.disconnect();}}catch(Exception ignored){}return "";}
    void filter(String category){ArrayList<Article>out=new ArrayList<>();for(Article a:articles)if("ALL".equals(category)||a.category.equalsIgnoreCase(category))out.add(a);render(out);}
    void render(ArrayList<Article>list){feed.removeAllViews();Collections.sort(list,(a,b)->Long.compare(b.published,a.published));HashSet<String>seen=new HashSet<>();int count=0;for(Article a:list){String key=a.title.toLowerCase(Locale.US).replaceAll("[^a-z0-9 ]","").trim();if(seen.contains(key)||key.isEmpty())continue;seen.add(key);addCard(a);if(++count>=80)break;}status.setText(count+" stories • updated just now");}
    void addCard(Article a){
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(18),dp(16),dp(18),dp(16));card.setBackground(bg(Color.rgb(21,27,40),Color.rgb(42,51,70),18));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,0,0,dp(12));card.setLayoutParams(cp);
        TextView meta=text(a.source+"  •  "+a.category,12,accent(a.category));meta.setTypeface(null,1);card.addView(meta);
        TextView title=text(a.title,19,Color.WHITE);title.setTypeface(null,1);title.setPadding(0,dp(7),0,dp(8));card.addView(title);
        if(!a.imageUrl.isEmpty()){ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.CENTER_CROP);image.setBackground(bg(Color.rgb(30,37,52),Color.rgb(45,55,75),14));card.addView(image,new LinearLayout.LayoutParams(-1,dp(185)));loadImage(image,a.imageUrl);}
        if(!a.description.isEmpty()){String d=a.description.length()>180?a.description.substring(0,180)+"…":a.description;TextView desc=text(d,14,Color.rgb(181,190,207));desc.setPadding(0,dp(8),0,0);card.addView(desc);}
        TextView open=text("READ ORIGINAL  →",12,accent(a.category));open.setTypeface(null,1);open.setPadding(0,dp(14),0,0);card.addView(open);View.OnClickListener go=v->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(a.link)));}catch(Exception ignored){}};card.setOnClickListener(go);feed.addView(card);
    }
    void loadImage(ImageView view,String url){executor.submit(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(10000);c.setRequestProperty("User-Agent","Mozilla/5.0 TechPulse");try(InputStream in=c.getInputStream()){android.graphics.Bitmap b=android.graphics.BitmapFactory.decodeStream(in);if(b!=null)main.post(()->view.setImageBitmap(b));}finally{c.disconnect();}}catch(Exception ignored){}});}
    @Override protected void onDestroy(){executor.shutdownNow();super.onDestroy();}
}
